#!/usr/bin/env bash

# This script is triggered when new files are copied to each Splunk Deployment Server

echo "Restarting all Splunk DS Nodes..."
ansible-playbook -i inventory.yml ansible-splunk-restart.yml



