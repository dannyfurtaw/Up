#!/usr/bin/env bash

# This script was created for the purpose of being run as a cron job
# The contents of the 'ansible_splunk_main.yml' file contain the following structure:
# 1.) Ansible checks into GitLab and compares a local repository with the Splunk DS repository
# 2.) When changes are made in GitLab, these changes are then replicated to the Ansible repository
# 3.) Ansible pushes these local repository changes to each individual Splunk DS repository
# 4.) Ansible prompts each Splunk DS to restart the Splunk service for changes to take effect

cd ~/Ansible/Splunk/deployment-servers/ansible-deployment-splunk

ansible-playbook -i localinventory.yml ansible-splunk-main.yml


