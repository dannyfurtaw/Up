# This script is triggered when executable file permissions are changed due to a new Splunk app being deployed

echo "Pushing file permission changes to GitLab"
cd /home/mcs_automation/Ansible/Splunk/deployment-servers/ansible-deployment-splunk
ansible-playbook -i localinventory.yml ansible-splunk-push.yml